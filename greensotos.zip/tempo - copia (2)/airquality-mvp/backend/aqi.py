# Conversión PM2.5 -> AQI (EPA, simplificado)
BANDS = [
    (0.0, 12.0, 0, 50, "Bueno"),
    (12.1, 35.4, 51, 100, "Moderado"),
    (35.5, 55.4, 101, 150, "Insalubre sensibles"),
    (55.5, 150.4, 151, 200, "Insalubre"),
    (150.5, 250.4, 201, 300, "Muy insalubre"),
    (250.5, 500.4, 301, 500, "Peligroso"),
]

def pm25_to_aqi(pm: float):
    for Cl, Ch, Il, Ih, label in BANDS:
        if Cl <= pm <= Ch:
            aqi = round(((Ih - Il) / (Ch - Cl)) * (pm - Cl) + Il)
            return {"aqi": aqi, "label": label}
    return {"aqi": 500, "label": "Peligroso"}
