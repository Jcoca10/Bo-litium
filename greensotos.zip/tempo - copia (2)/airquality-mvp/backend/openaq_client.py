import requests
from typing import Optional, Dict

BASE = "https://api.openaq.org/v2"

def nearest_pm25(lat: float, lon: float) -> Optional[Dict]:
    """Busca la medición PM2.5 más reciente cerca de (lat, lon)."""
    url = f"{BASE}/measurements"
    params = {
        "parameter": "pm25",
        "limit": 1,
        "sort": "desc",
        "order_by": "date",
        "coordinates": f"{lat},{lon}",
        "radius": 25000,  # 25 km
    }
    try:
        r = requests.get(url, params=params, timeout=12)
        r.raise_for_status()
        data = r.json().get("results", [])
        return data[0] if data else None
    except Exception:
        return None
