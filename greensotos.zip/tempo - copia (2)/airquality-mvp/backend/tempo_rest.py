# backend/tempo_rest.py
import os
import time
import io
import json
from typing import Tuple, Optional, Dict, Any, List

import requests
import numpy as np

try:
    import xarray as xr
except Exception:
    xr = None

HARMONY_URL = os.environ.get("HARMONY_URL", "https://harmony.earthdata.nasa.gov")

def _auth_headers() -> Dict[str, str]:
    token = os.environ.get("EDL_TOKEN", "").strip()
    if not token:
        user = os.environ.get("EDL_USERNAME")
        pwd = os.environ.get("EDL_PASSWORD")
        if user and pwd:
            r = requests.post(
                "https://urs.earthdata.nasa.gov/api/users/token",
                auth=(user, pwd),
                timeout=60,
            )
            r.raise_for_status()
            token = r.json().get("token", "")
    if not token:
        raise RuntimeError("No Earthdata token. Exporta EDL_TOKEN o EDL_USERNAME/EDL_PASSWORD")
    return {"Authorization": f"Bearer {token}"}

def start_job(collection_concept_id: str,
              bbox: Tuple[float, float, float, float],
              start_iso: str,
              end_iso: str,
              out_format: str = "application/x-netcdf4",
              variables: Optional[List[str]] = None) -> str:
    """
    Crea un Job en Harmony usando REST. 'variables' puede contener concept-ids V...
    """
    url = f"{HARMONY_URL}/jobs"
    headers = {
        "Accept": "application/json",
        **_auth_headers(),
    }
    data = {
        "source": collection_concept_id,
        "format": out_format,
        "temporal.start": start_iso,
        "temporal.end": end_iso,
        "spatial.bbox": f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}",
    }
    # Si hay variables (V...), pásalas separadas por coma
    if variables:
        data["variables"] = ",".join(variables)

    r = requests.post(url, headers=headers, data=data, timeout=90)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Harmony jobs POST {r.status_code}: {r.text}")
    js = r.json()
    job_id = js.get("jobID") or js.get("job_id") or js.get("id")
    if not job_id:
        raise RuntimeError(f"No job id en respuesta: {js}")
    return job_id

def wait_job(job_id: str, max_wait_s: int = 600, poll_every_s: int = 3) -> Dict[str, Any]:
    headers = {"Accept": "application/json", **_auth_headers()}
    url = f"{HARMONY_URL}/jobs/{job_id}"
    t0 = time.time()
    while True:
        r = requests.get(url, headers=headers, timeout=60)
        r.raise_for_status()
        js = r.json()
        status = (js.get("status") or "").lower()
        if status in ("successful", "complete", "completed", "done"):
            return js
        if status in ("failed", "error"):
            raise RuntimeError(f"Harmony job failed: {json.dumps(js)}")
        if time.time() - t0 > max_wait_s:
            raise TimeoutError(f"Harmony job timeout: {job_id}")
        time.sleep(poll_every_s)

def download_first_asset(job_json: Dict[str, Any]) -> bytes:
    headers = _auth_headers()
    links: List[Dict[str, Any]] = job_json.get("links", []) or []
    for lk in links:
        if (lk.get("rel") or "").endswith("/data"):
            href = lk.get("href")
            if href:
                r = requests.get(href, headers=headers, timeout=180)
                r.raise_for_status()
                return r.content
    raise RuntimeError("No se encontró link de datos en respuesta de Harmony")

def mean_no2_from_bytes(blob: bytes, var_candidates=("no2", "no2_column", "ColumnAmountNO2Trop", "ColumnAmountNO2")) -> Dict[str, Any]:
    if xr is None:
        raise RuntimeError("xarray no instalado. pip install xarray netCDF4")
    with xr.open_dataset(io.BytesIO(blob)) as ds:
        var_name = None
        for cand in var_candidates:
            if cand in ds.variables:
                var_name = cand
                break
        if var_name is None:
            low = {k.lower(): k for k in ds.variables.keys()}
            for cand in var_candidates:
                if cand.lower() in low:
                    var_name = low[cand.lower()]
                    break
        if var_name is None:
            raise RuntimeError(f"No se encontró variable NO2 en dataset. Vars: {list(ds.variables.keys())[:20]}...")
        arr = np.array(ds[var_name].load().values, dtype=np.float64)
        arr = arr[np.isfinite(arr)]
        if arr.size == 0:
            raise RuntimeError("La variable NO2 no tiene valores finitos en el subset")
        return {
            "variable": var_name,
            "mean": float(np.nanmean(arr)),
            "min": float(np.nanmin(arr)),
            "max": float(np.nanmax(arr)),
            "n_pixels": int(arr.size),
            "units": str(getattr(ds[var_name], "units", "")),
        }

def tempo_no2_mean(collection_id: str,
                   bbox: Tuple[float, float, float, float],
                   date_iso: str,
                   variables: Optional[List[str]] = None) -> Dict[str, Any]:
    start = f"{date_iso}T00:00:00Z"
    end   = f"{date_iso}T23:59:59Z"
    job_id = start_job(collection_id, bbox, start, end,
                       out_format="application/x-netcdf4",
                       variables=variables)
    job_json = wait_job(job_id, max_wait_s=900)
    blob = download_first_asset(job_json)
    stats = mean_no2_from_bytes(blob)
    stats.update({"date": date_iso, "source": "Harmony TEMPO L2", "job_id": job_id})
    return stats
