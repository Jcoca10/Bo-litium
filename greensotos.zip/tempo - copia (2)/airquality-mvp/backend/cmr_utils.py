# backend/cmr_utils.py
import requests

CMR = "https://cmr.earthdata.nasa.gov"

def resolve_collection_from_variable(variable_concept_id: str) -> str:
    """
    Dado un concept-id de VARIABLE (V...), devuelve un concept-id de COLECCIÓN (C...)
    usando la API de asociaciones de CMR.
    """
    url = f"{CMR}/search/associations"
    r = requests.get(url, params={
        "variable_concept_id": variable_concept_id,
        "format": "json",
        "page_size": 50,
    }, timeout=60)
    r.raise_for_status()
    js = r.json()
    # La respuesta trae items con concept_id de colecciones
    items = js.get("items") or []
    for it in items:
        cid = it.get("concept_id") or it.get("id")
        if isinstance(cid, str) and cid.startswith("C"):
            return cid
    raise RuntimeError(f"No se encontró colección asociada a {variable_concept_id}")
