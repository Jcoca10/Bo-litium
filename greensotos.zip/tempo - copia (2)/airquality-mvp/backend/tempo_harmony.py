# backend/tempo_harmony.py
import os
import tempfile
import time
from typing import Optional, Tuple, List

import numpy as np
import xarray as xr
import requests
from harmony import Client

# Colección por defecto: TEMPO NO2 L2 V03 en LARC cloud (CMR concept id)
DEFAULT_COLLECTION_ID = os.getenv("TEMPO_COLLECTION_ID", "C2930725014-LARC_CLOUD")

def _get_harmony_client() -> Client:
    """
    Crea un cliente Harmony con credenciales desde variables de entorno.
    Admite:
      - EDL_TOKEN (Bearer)
      - EDL_USERNAME + EDL_PASSWORD (Basic, usando .netrc interno)
    """
    token = os.getenv("EDL_TOKEN")
    if token:
        # harmony-py toma el token si está en el entorno como 'EDL_TOKEN'
        # No hace falta nada adicional
        pass
    else:
        # Si no hay token, intenta usuario y password
        if not (os.getenv("EDL_USERNAME") and os.getenv("EDL_PASSWORD")):
            raise RuntimeError(
                "Configura EDL_TOKEN o EDL_USERNAME/EDL_PASSWORD para Earthdata Login"
            )
    return Client()

def _bbox(lat: float, lon: float, half_width_deg: float = 0.20) -> Tuple[float, float, float, float]:
    """
    Devuelve (minLon, minLat, maxLon, maxLat).
    half_width_deg ~ 0.20º ~ ~22 km; ajusta según necesites.
    """
    return (lon - half_width_deg, lat - half_width_deg, lon + half_width_deg, lat + half_width_deg)

def _pick_no2_var(ds: xr.Dataset) -> Optional[str]:
    """
    Busca en el NetCDF alguna variable que parezca NO2 tropospheric column.
    Diferentes versiones pueden variar el nombre; aquí escaneamos heurísticamente.
    """
    candidates: List[str] = []
    for v in list(ds.data_vars):
        low = v.lower()
        if "no2" in low and ("trop" in low or "column" in low or "vertical" in low):
            candidates.append(v)
    # si no encontró, intenta solo "no2"
    if not candidates:
        for v in list(ds.data_vars):
            if "no2" in v.lower():
                candidates.append(v)
    return candidates[0] if candidates else None

def tempo_no2_mean(
    lat: float,
    lon: float,
    date_iso: str,
    half_width_deg: float = 0.20,
    collection_id: Optional[str] = None,
):
    """
    Pide a Harmony un subset de TEMPO L2 NO2 para el bbox y fecha dados.
    Retorna dict con promedio, n_pixeles, units, variable, etc.
    """
    coll = collection_id or DEFAULT_COLLECTION_ID
    c = _get_harmony_client()

    # temporal (día completo UTC)
    start = f"{date_iso}T00:00:00Z"
    end   = f"{date_iso}T23:59:59Z"
    bbox = _bbox(lat, lon, half_width_deg)

    # Lanzar petición: salida en netCDF4
    req = c.submit(
        coll,
         bbox=list(bbox),           # [minLon,minLat,maxLon,maxLat]
        temporal=(start, end),
        format="application/x-netcdf4",         # NetCDF4
    )

    # Esperar finalización (polling)
    # harmony-py expone .status() y .messages(); también podemos iterar .results()
    # Aquí haremos un loop corto.
    for _ in range(120):
        st = req.status()
        if st == "successful":
            break
        if st in ("failed", "canceled"):
            raise RuntimeError(f"Harmony request {req.request_id} terminó en estado: {st}")
        time.sleep(2)

    if req.status() != "successful":
        raise RuntimeError(f"Harmony tardó demasiado o no finalizó: {req.request_id}")

    # Descarga primer resultado
    urls = [r.href for r in req.results()]
    if not urls:
        raise RuntimeError("Harmony no devolvió archivos para ese bbox/fecha (fuera de cobertura TEMPO)")

    url0 = urls[0]
    # Autorización con token si aplica
    headers = {}
    token = os.getenv("EDL_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    with tempfile.NamedTemporaryFile(suffix=".nc", delete=False) as tf:
        r = requests.get(url0, headers=headers, stream=True)
        r.raise_for_status()
        for chunk in r.iter_content(chunk_size=1<<20):
            tf.write(chunk)
        tmp_path = tf.name

    # Abrir NetCDF con xarray
    ds = xr.open_dataset(tmp_path)

    # Buscar variable NO2 más apropiada
    varname = _pick_no2_var(ds)
    if not varname:
        # fallback: promedio de todos los DataArray numéricos
        numeric_vars = [v for v in ds.data_vars if np.issubdtype(ds[v].dtype, np.number)]
        if not numeric_vars:
            raise RuntimeError("No se hallaron variables numéricas en el NetCDF")
        arr = xr.concat([ds[v] for v in numeric_vars], dim="stacked_vars").mean("stacked_vars")
        mean_val = float(arr.where(np.isfinite(arr)).mean().values)
        units = ds[numeric_vars[0]].attrs.get("units", "")
        varname = numeric_vars[0]
    else:
        arr = ds[varname]
        # máscara de válidos
        arr = arr.where(np.isfinite(arr))
        mean_val = float(arr.mean().values)
        units = ds[varname].attrs.get("units", "")

    # cuenta de píxeles válidos usados
    valid_count = int(np.count_nonzero(np.isfinite(arr.values)))

    return {
        "ok": True,
        "source": "TEMPO L2 via Harmony",
        "collection_id": coll,
        "variable": varname,
        "units": units,
        "lat": lat,
        "lon": lon,
        "date": date_iso,
        "bbox_deg": list(bbox),
        "mean": mean_val,
        "n_pixels": valid_count,
        "download_url": url0,
        "request_id": req.request_id,
    }
