# backend/main.py
from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
from tempo_harmony import tempo_no2_mean

app = FastAPI(title="AirQuality MVP API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/tempo/no2")
def tempo_no2(
    lat: float = Query(..., ge=-90, le=90),
    lon: float = Query(..., ge=-180, le=180),
    date: str = Query(..., description="YYYY-MM-DD en UTC"),
    half_width_deg: float = Query(0.20, ge=0.05, le=1.0),
    collection_id: Optional[str] = Query(None, description="CMR concept id opcional"),
):
    """
    Devuelve el NO2 (columna troposférica) promedio de TEMPO L2 (subset Harmony)
    para un bbox pequeño alrededor de (lat,lon) y una fecha dada.
    """
    try:
        res = tempo_no2_mean(lat, lon, date, half_width_deg=half_width_deg, collection_id=collection_id)
        return res
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
